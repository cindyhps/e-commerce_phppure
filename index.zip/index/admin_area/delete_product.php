<?php
include('../includes/connect.php');

if(isset($_GET['id']) && !empty($_GET['id'])){
    $product_id = $_GET['id'];

    // Query untuk menghapus produk berdasarkan ID
    $delete_product_query = "DELETE FROM products WHERE product_id = ?";

    if ($stmt = mysqli_prepare($con, $delete_product_query)) {
        mysqli_stmt_bind_param($stmt, "i", $product_id);
        mysqli_stmt_execute($stmt);

        if(mysqli_stmt_affected_rows($stmt) > 0){
            echo "<script>alert('Product has been deleted')</script>";
            echo "<script>window.open('index_admin.php','_self')</script>"; // Redirect ke halaman admin setelah menghapus
        } else {
            echo "<script>alert('Error: Could not delete product')</script>";
            echo "<script>window.open('index_admin.php','_self')</script>"; // Redirect ke halaman admin jika terjadi kesalahan
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('Error: Could not prepare statement')</script>";
        echo "<script>window.open('index_admin.php','_self')</script>"; // Redirect ke halaman admin jika gagal membuat statement
    }
} else {
    echo "<script>alert('Invalid Product ID')</script>";
    echo "<script>window.open('index_admin.php','_self')</script>"; // Redirect ke halaman admin jika ID produk tidak valid
}

// Tutup koneksi database
mysqli_close($con);
?>
