<?php

$con=mysqli_connect('localhost','root','','store_tugas');
if(!$con){
    die(mysqli_error($con));
}

?>